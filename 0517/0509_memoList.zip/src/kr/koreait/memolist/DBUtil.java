package kr.koreait.memolist;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

//	mysql에 연결하는 메소드
	public static Connection getMysqlConnection() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/weekjsp?useUnicode=true&characterEncoding=UTF-8";
			conn = DriverManager.getConnection(url, "root", "0000");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
//	oracle에 연결하는 메소드
	public static Connection getOracleConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(url, "koreait", "0000");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
}







