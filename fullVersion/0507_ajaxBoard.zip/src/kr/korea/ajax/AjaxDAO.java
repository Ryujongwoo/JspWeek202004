package kr.korea.ajax;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AjaxDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public AjaxDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "koreait";
			String password = "0000";
			conn = DriverManager.getConnection(url, user, password);
//			System.out.println("연결성공 : " + conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	검색어로 입력된 문자열이 이름에 포함된 레코드만 얻어오는 메소드
	public ArrayList<AjaxVO> search(String name) {
		ArrayList<AjaxVO> ajaxList = new ArrayList<AjaxVO>();
		try {
			String sql = "select * from ajax where name like ? order by idx";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, '%' + name + '%');
			rs = pstmt.executeQuery();
			while (rs.next()) {
				AjaxVO vo = new AjaxVO();
				vo.setIdx(rs.getInt("idx"));
				vo.setName(rs.getString("name"));
				vo.setAge(rs.getInt("age"));
				vo.setGender(rs.getString("gender"));
				vo.setEmail(rs.getString("email"));
				ajaxList.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ajaxList;
	}

//	데이터를 테이블에 저장하는 메소드
	public int insert(AjaxVO vo) {
		try {
//			System.out.println(vo);
			String sql = "insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getName());
			pstmt.setInt(2, vo.getAge());
			pstmt.setString(3, vo.getGender());
			pstmt.setString(4, vo.getEmail());
//			sql 명령이 정상적으로 실행되면 정상적으로 실행된 sql 명령의 개수를 리턴시킨다. => sql 명령이 정상적으로 실행되면 1이 리턴된다.
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
//		sql 명령문에 오류가 있으면 -1을 리턴시킨다.
		return -1;
	}
	
}


















