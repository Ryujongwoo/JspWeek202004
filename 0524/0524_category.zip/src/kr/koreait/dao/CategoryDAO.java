package kr.koreait.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.vo.CategoryVO;

public class CategoryDAO {

	private static CategoryDAO instance = new CategoryDAO();
	private CategoryDAO() { }
	public static CategoryDAO getInstance() { return instance; }
	
//	CategoryService 클래스에서 mapper와 메인 카테고리 정보가 저장된 객체를 넘겨받고 category.xml 파일의 insert sql 명령을 실행하는
//	메소드
	public void insert(SqlSession mapper, CategoryVO vo) {
		mapper.insert("insert", vo);
	}
	
//	CategoryService 클래스에서 mapper를 넘겨받고 category.xml 파일의 select sql 명령을 실행하는 메소드
	public ArrayList<CategoryVO> selectList(SqlSession mapper) {
//		selectOne() : ibatis의 queryForObject() 메소드와 같은 기능을 실행한다. => 결과 1건인 select
//		selectList() : ibatis의 queryForList() 메소드와 같은 기능을 실행한다. => 결과 여러건인 select
		return (ArrayList<CategoryVO>) mapper.selectList("selectList");
	}

}
