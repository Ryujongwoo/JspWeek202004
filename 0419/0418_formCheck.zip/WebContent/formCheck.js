//	자바스크립트 함수의 형식
//	function 함수이름([인수, ...]) {
//		함수가 실행할 문장;
//		...;
//		[return 값;]
//	}

//	이벤트가 실행되는 객체(주민등록번호 앞, 뒤자리)에 최대 글자수 만큼 문자가 입력되면 지정된 객체로 포커스를 넘겨주는 함수
//	moveNext(이벤트가 실행되는 객체, 최대 글자수, 포커스를 넘겨줄 객체)
	function moveNext(obj, len, nextObj) {
//		value : 객체에 입력된 문자열 자체
//		length : 객체에 입력된 문자열의 개수
		if(obj.value.trim().length == len) {
			nextObj.focus();
		}
	}

//	폼에 입려된 주민등록번호가 올바른 데이터인가 검사하는 함수
//	formCheck(검사할 데이터가 입력된 폼)
//	obj로 this가 넘어오므로 obj에는 document.juminForm이 저장된다.
	function formCheck(obj) {
		
//		주민등록번호 앞 자리에 데이터가 입력되었나 검사한다. => 아무것도 입력되지 않았거나 모두 공백인 경우
//		obj.j1.value => 주민등록번호 앞자리(j1)에 입력된 데이터(value)가 있으면 true, 없으면 false
//		obj.j1.value.trim().length == 0 => 모두 공백이 입력되었나?
		if(!obj.j1.value || obj.j1.value.trim().length == 0) {
			alert("주민등록번호 앞 자리를 입력하세요");
			obj.j1.value = "";
			obj.j1.focus();
//			폼에 오류가 발생되면 false를 리턴하고 함수가 종료된다.
			return false;
		}
		
//		주민등록번호 앞 자리에 6글자가 입력되었나 검사한다.
		if(obj.j1.value.trim().length != 6) {
			alert("주민등록번호 앞 자리는 6글자를 입력하세요");
			obj.j1.value = "";
			obj.j1.focus();
			return false;
		}
		
//		주민등록번호 앞 자리에 숫자만 입력되었나 검사한다.
//		Number() : 인수로 지정된 문자열을 숫자로 변환한다.
//		isNaN() : NaN => Not a Number, 인수로 지정된 데이터가 숫자가 아니면 true, 숫자면 false를 리턴시킨다.
		if(isNaN(Number(obj.j1.value))) {
			alert("주민등록번호 앞 자리는 숫자만 입력하세요");
			obj.j1.value = "";
			obj.j1.focus();
			return false;
		}
		
//		주민등록번호 뒷 자리를 검사한다.
		if(!obj.j2.value || obj.j2.value.trim().length == 0) {
			alert("주민등록번호 뒷 자리를 입력하세요");
			obj.j2.value = "";
			obj.j2.focus();
			return false;
		}
		if(obj.j2.value.trim().length != 7) {
			alert("주민등록번호 뒷 자리는 7글자를 입력하세요");
			obj.j2.value = "";
			obj.j2.focus();
			return false;
		}
		if(isNaN(Number(obj.j2.value))) {
			alert("주민등록번호 뒷 자리는 숫자만 입력하세요");
			obj.j2.value = "";
			obj.j2.focus();
			return false;
		}
		
//		여기까지 왔다는 것은 주민등록번호는 13자리의 숫자가 입력되었다는 의미이다. => 주민등록번호 유효성 검사
//		주민등록번호 유효성 검사를 하기 위해서 주민등록번호를 하나의 문자열로 합친다.
//		자바스크립트 숫자로만 구성된 문자열을 사칙연산을 할 경우 덧셈을 하는 경우에는 문자열을 이어 붙이고 덧셈을 제외한 나머지 
//		연산은 지가 알아서 숫자로 변환시킨 후 연산한다.
		jumin = obj.j1.value + obj.j2.value;
//		숫자로만 구성된 문자열을 덧셈 연산을 하려면 Number() 함수를 사용해서 숫자로 변환시킨 후 해야한다.
//		jumin = Number(obj.j1.value) + Number(obj.j2.value);
//		alert(jumin);

//		주민등록번호의 각 자리 숫자에 가중치를 곱한 합계를 계산한다. // 둘리 주민등록번호 => 8304221185600
		sum = 0;
		for(i = 0; i < 12; i++) {
//			sum += jumin.charAt(i) * (i < 8 ? i + 2 : i - 6);
			sum += jumin.charAt(i) * (i % 8 + 2);
		}
//		alert(sum); // 둘리 주민등록번호 기준 143이 계산된다.

//		주민등록번호의 각 자리 숫자와 가중치를 곱한 숫자의 합계를 11로 나눈 나머지를 계산한다.
//		11에서 나머지를 뺀 결과가 2자리면 10의 자리는 버리고 1의 자리만 취한다.
//		이 결과가 주민등록번호의 마지막 자리와 같으면 정상적인 주민등록번호이고 다르면 올바르지 않은 주민등록번호가 된다.
		result = (11 - sum % 11) % 10;
//		자바스크립트는 문자와 숫자를 비교할 경우 문자를 지가 알아서 숫자로 변환한 후 비교해준다.
		if(jumin.charAt(12) != result) {
			alert("올바른 주민등록번호가 아닙니다. 넌... 누구냐??");
			obj.j1.value = "";
			obj.j2.value = "";
			obj.j1.focus();
			return false;
		}
		
//		폼에 오류없이 여기까지 실행되었다면 정상적인 데이터가 입력되것이므로 true를 리턴시킨다.
		return true;
	}
