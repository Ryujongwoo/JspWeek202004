package kr.koreait.service;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.MvcBoardDAO;
import kr.koreait.mybatis.MySession;
import kr.koreait.vo.MvcBoardVO;

public class MvcBoardService {

	private static MvcBoardService instance = new MvcBoardService();
	private MvcBoardService() { }
	public static MvcBoardService getInstance() { return instance; }

//	컨트롤러에서 호출되는 테이블에 저장할 글 한 건이 저장된 객체를 넘겨받고 mapper를 얻어오는 메소드
	public void insert(MvcBoardVO vo) {
		System.out.println("MvcBoardService 클래스의 insert() 메소드 실행");
		SqlSession mapper = MySession.getSession();
		MvcBoardDAO.getInstance().insert(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
}







