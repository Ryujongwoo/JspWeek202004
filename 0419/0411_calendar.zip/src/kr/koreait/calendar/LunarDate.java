package kr.koreait.calendar;


public class LunarDate {

	private int year;
	private int month;
	private int day;
	private int yearLunar;
	private int monthLunar;
	private int dayLunar;
	private boolean lunarFlag;
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getYearLunar() {
		return yearLunar;
	}
	public void setYearLunar(int yearLunar) {
		this.yearLunar = yearLunar;
	}
	public int getMonthLunar() {
		return monthLunar;
	}
	public void setMonthLunar(int monthLunar) {
		this.monthLunar = monthLunar;
	}
	public int getDayLunar() {
		return dayLunar;
	}
	public void setDayLunar(int dayLunar) {
		this.dayLunar = dayLunar;
	}
	public boolean isLunarFlag() {
		return lunarFlag;
	}
	public void setLunarFlag(boolean lunarFlag) {
		this.lunarFlag = lunarFlag;
	}
	
	@Override
	public String toString() {
		return String.format("양력 %04d년 %02d월 %02d일은 음력 %s %04d년 %02d월 %02d일 입니다.", year, month, day, lunarFlag ? "윤" : "", yearLunar, monthLunar, dayLunar);
	}
	
}
