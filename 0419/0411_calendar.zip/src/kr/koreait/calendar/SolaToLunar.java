package kr.koreait.calendar;

import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SolaToLunar {

	public static ArrayList<LunarDate> solaToLunar(int year, int month) {

		ArrayList<LunarDate> list = new ArrayList<LunarDate>();
		String urlAddr = String.format("https://astro.kasi.re.kr/life/pageView/5?search_year=%04d&search_month=%02d", year, month);

		Document doc = null;
		try {
			doc = Jsoup.connect(urlAddr).get();
//			System.out.println(doc);
			
			Elements element = doc.select("table tbody tr");
			for(Element ele : element) {
				Elements elements = ele.select("td");

				String sola = elements.get(0).text();
				String lunar = elements.get(1).text();
//				System.out.print("양력 : " + sola);
//				System.out.println(", 음력 : " + lunar);
				
				LunarDate lunarDate = new LunarDate();
				lunarDate.setYear(Integer.parseInt(sola.split("-")[0]));
				lunarDate.setMonth(Integer.parseInt(sola.split("-")[1]));
				lunarDate.setDay(Integer.parseInt(sola.split("-")[2].split(" ")[0]));
				lunarDate.setYearLunar(Integer.parseInt(lunar.split("-")[0]));
				lunarDate.setMonthLunar(Integer.parseInt(lunar.split("-")[1]));
				lunarDate.setDayLunar(Integer.parseInt(lunar.split("-")[2].split(" ")[0]));
				lunarDate.setLunarFlag(lunar.length() > 10 ? true : false);
//				System.out.println(lunarDate);
				
				list.add(lunarDate);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		return list;

	}
}









