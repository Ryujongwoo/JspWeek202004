package kr.koreait.calendar;

import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SolaToLunar {

	public static ArrayList<LunarDate> solaToLunar(int year, int month) {

		ArrayList<LunarDate> list = new ArrayList<LunarDate>();
		ArrayList<LunarDate> lunarList = new ArrayList<LunarDate>();
		String urlAddr = "";
		
		for(int i = 1 ; i <= 12; i++) {
			urlAddr = String.format("https://astro.kasi.re.kr/life/pageView/5?search_year=%04d&search_month=%02d", year, i);
			Document doc = null;
			try {
				doc = Jsoup.connect(urlAddr).get();
//				System.out.println(doc);
				
				Elements element = doc.select("table tbody tr");
				for(Element ele : element) {
					Elements elements = ele.select("td");
	
					String sola = elements.get(0).text();
					String lunar = elements.get(1).text();
//					System.out.print("양력 : " + sola);
//					System.out.println(", 음력 : " + lunar);
					
					LunarDate lunarDate = new LunarDate();
					lunarDate.setYear(Integer.parseInt(sola.split("-")[0]));
					lunarDate.setMonth(Integer.parseInt(sola.split("-")[1]));
					lunarDate.setDay(Integer.parseInt(sola.split("-")[2].split(" ")[0]));
					lunarDate.setYearLunar(Integer.parseInt(lunar.split("-")[0]));
					lunarDate.setMonthLunar(Integer.parseInt(lunar.split("-")[1]));
					lunarDate.setDayLunar(Integer.parseInt(lunar.split("-")[2].split(" ")[0]));
					lunarDate.setLunarFlag(lunar.length() > 10 ? true : false);
//					System.out.println(lunarDate);
					
					list.add(lunarDate);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		for(int i = 0; i < list.size(); i++) {
//			설
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 1 && list.get(i).getDayLunar() == 1) {
				list.get(i - 1).setLunar("<br><span>설날연휴</span>");
				list.get(i).setLunar("<br><span>설날</span>");
				list.get(i + 1).setLunar("<br><span>설날연휴</span>");
			}
//			석가탄신일
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 4 && list.get(i).getDayLunar() == 8) {
				list.get(i).setLunar("<br><span>부처님오신날</span>");
			}
//			추석
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 8 && list.get(i).getDayLunar() == 14) {
				list.get(i).setLunar("<br><span>추석연휴</span>");
			}
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 8 && list.get(i).getDayLunar() == 15) {
				list.get(i).setLunar("<br><span>추석</span>");
			}
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 8 && list.get(i).getDayLunar() == 16) {
				list.get(i).setLunar("<br><span>추석연휴</span>");
			}
//			일반공휴일
			if(list.get(i).getMonth() == 1 && list.get(i).getDay() == 1) {
				list.get(i).setLunar("<br><span>신정</span>");
			}
			if(list.get(i).getMonth() == 3 && list.get(i).getDay() == 1) {
				list.get(i).setLunar("<br><span>삼일절</span>");
			}
			if(list.get(i).getMonth() == 5 && list.get(i).getDay() == 1) {
				list.get(i).setLunar("<br><span>근로자의날</span>");
			}
			if(list.get(i).getMonth() == 5 && list.get(i).getDay() == 5) {
				list.get(i).setLunar("<br><span>어린이날</span>");
			}
			if(list.get(i).getMonth() == 6 && list.get(i).getDay() == 6) {
				list.get(i).setLunar("<br><span>현충일</span>");
			}
			if(list.get(i).getMonth() == 8 && list.get(i).getDay() == 15) {
				list.get(i).setLunar("<br><span>광복절</span>");
			}
//			개천절이 추석 연휴와 겹치는 경우
			if(list.get(i).getMonth() == 10 && list.get(i).getDay() == 3 && list.get(i).getLunar() != null) {
				System.out.println(list.get(i).getLunar());
				list.get(i).setLunar(list.get(i).getLunar() + "<br><span>개천절</span>");
			}
			if(list.get(i).getMonth() == 10 && list.get(i).getDay() == 3 && list.get(i).getLunar() == null) {
				list.get(i).setLunar("<br><span>개천절</span>");
			}
//			발생될지는 모르겠지만 한글날이 추석 연휴와 겹치는 경우
			if(list.get(i).getMonth() == 10 && list.get(i).getDay() == 9 && list.get(i).getLunar() != null) {
				list.get(i).setLunar(list.get(i).getLunar() + "<br><span>한글날</span>");
			}
			if(list.get(i).getMonth() == 10 && list.get(i).getDay() == 9 && list.get(i).getLunar() == null) {
				list.get(i).setLunar("<br><span>한글날</span>");
			}
			if(list.get(i).getMonth() == 12 && list.get(i).getDay() == 25) {
				list.get(i).setLunar("<br><span>크리스마스</span>");
			}
//			어린이날 대체공휴일 처리			
			if(list.get(i).getMonth() == 5 && list.get(i).getDay() == 6) {
				if(MyCalendar.weekDay(year, 5, 5) == 0) {
					list.get(i).setLunar("<br><span>대체공휴일</span>");
				}
			}
			if(list.get(i).getMonth() == 5 && list.get(i).getDay() == 7) {
				if(MyCalendar.weekDay(year, 5, 5) == 6) {
					list.get(i).setLunar("<br><span>대체공휴일</span>");
				}
			}
//			설날 연휴 대체공휴일 처리
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 1 && list.get(i).getDayLunar() == 1) {
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 4) {
					list.get(i + 3).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 5) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 6) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 0) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
			}
//			추석 연휴 대체공휴일 처리
			if(!list.get(i).isLunarFlag() && list.get(i).getMonthLunar() == 8 && list.get(i).getDayLunar() == 15) {
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 4) {
					list.get(i + 3).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 5) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 6) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, list.get(i - 1).getMonth(), list.get(i - 1).getDay()) == 0) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
//				추석 연휴에 개천절이 끼어있는 경우
				if((list.get(i - 1).getDay() == 3 || list.get(i).getDay() == 3 || list.get(i + 1).getDay() == 3) &&
						MyCalendar.weekDay(year, month, 3) != 4) {
					list.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
			}
		}
		
		for(int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
			if(list.get(i).getMonth() == month) {
				lunarList.add(list.get(i));
			}
		}
		
//		for(int i = 0; i < lunarList.size(); i++) {
//			System.out.println(lunarList.get(i));
//		}
		
		return lunarList;

	}
}









